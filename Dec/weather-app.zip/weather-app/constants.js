
export const WEATHER_API_BASE_URL = "https://api.openweathermap.org/data/2.5/weather";

export const WEATHER_API_KEY = "98fefb1e26b52c5109dabaa88d3e247a";