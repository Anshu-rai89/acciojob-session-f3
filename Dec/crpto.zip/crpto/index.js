

const cryptoDashTableElement = document.getElementById("crpto-dash");
/**
 *  It Renders Rows for Crypto Dashboard
 *  @param {Array}cryptoData 
 */
  function addCryptoDashTableRow( cryptoData) {
    
    const cryptoRowElement = document.createElement('tr');
  
    const cryptoImageTdElement = document.createElement('td');

    const cryptoImageElement = document.createElement('img');
    cryptoImageElement.src = cryptoData.image;
    cryptoImageElement.classList.add("crypto-image");
    cryptoImageTdElement.appendChild(cryptoImageElement);

    cryptoRowElement.appendChild(cryptoImageTdElement);

    cryptoDashTableElement.appendChild(cryptoRowElement);

    // I have to create a Row using Tr element 
    // I have to add Td elements inside my row
  }
/**
 *  It fetches crypto data from server using a http get method
 *  JS Docs
 */
const fetchCryptoData = async () => {
    // We have to make api call & get the data
    const requestUrl = 'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=10&page=1&sparkline=false';
    const response = await fetch(requestUrl,{
        method:"GET"
    });
    const cryptoData = await response.json();

    cryptoData.forEach((crypto) => {
      addCryptoDashTableRow(crypto);
    });
   
    // Render our Dashboard 
}


document.addEventListener('DOMContentLoaded',fetchCryptoData)